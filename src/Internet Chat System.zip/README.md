# Internet Chat System 
## Running Instructions
### Compiling  
Run: 
``
javac *.java
``
### Running the Chat Server  
To run the server use:
``
java Server
``
### Running the client  
Running the client requires that you give the IP address of the server as per the project requirements  
To run client, use: 
``
java Client 127.0.0.1
``  
In case your sever is in a different machine, you should specify its IP address   
i.e.
``
java Client 192.168.0.0.1
``

Happy Kuokoa Sem...